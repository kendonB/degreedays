library(testthat)
library(degreedays)

test_check("degreedays")
