#' @title Dot product calculator
#' @export
parDotProd <- function(x, y){
  parInnProd(x, y)
}